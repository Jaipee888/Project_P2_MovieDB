package com.example.jaypr_000.project_moviedb_p2;

public interface OnItemClickListener {
    void onItemClick(MovieData item);
}
